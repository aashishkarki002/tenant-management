export const ACCOUNTING_CONFIG = {
  // ExpenseSource.code to use for maintenance-related expenses
  MAINTENANCE_EXPENSE_SOURCE_CODE: "MAINTENANCE",

  // Default expense account code for maintenance in the ledger
  MAINTENANCE_EXPENSE_CODE: "5000",
};
